# from django.db import models
#
# from Apps.Organization.models import Course, Session, Organization, SemesterAndYear
# from django.contrib.auth import get_user_model
#
# User = get_user_model()
#
#
# class Student(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization_id = models.ForeignKey(Organization, on_delete=models.CASCADE)
#     first_name = models.CharField(max_length=255)
#     middle_name = models.CharField(max_length=255)
#     last_name = models.CharField(max_length=255)
#     father_name = models.CharField(max_length=255)
#     mother_name = models.CharField(max_length=255)
#     dob = models.DateField()
#     course_id = models.ForeignKey(Course, on_delete=models.DO_NOTHING, default=1)
#     session_year_id = models.ForeignKey(Session, on_delete=models.CASCADE)
#     gender = models.CharField(max_length=255)
#     email = models.EmailField()
#     mobile_no = models.IntegerField()
#     parent_contact = models.IntegerField()
#     entry_year = models.DateField()
#     aadhar = models.CharField(max_length=12)
#     school_code = models.CharField(max_length=255)
#     student_code = models.CharField(max_length=255)
#     profile_pic = models.ImageField(blank=True, null=True, upload_to='student_image')
#     district = models.CharField(max_length=255)
#     state = models.CharField(max_length=255)
#     postal_code = models.IntegerField()
#     current_address = models.TextField(max_length=255)
#     permanent_address = models.TextField(max_length=255)
#     INACTIVE = 0
#     ACTIVE = 1
#     STATUS_CHOICES = (
#         (INACTIVE, 'Inactive'),
#         (ACTIVE, 'Active'),
#     )
#     status = models.SmallIntegerField(choices=STATUS_CHOICES, default=0)
#     created_by = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#     def __str__(self):
#         return self.first_name
#
#     def get_student_details(self):
#         student_details = "This contains the details of each and every student in the school along with their " \
#                          "personal details, which class they belong to"
#         return student_details
#
#     def get_fees_details(self):
#         fees_details = "This method shows the fee details of each student and allows the student to pay the fees"
#         return fees_details
#
# """
# class AcademicRecord(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     Student = models.ForeignKey(Student, on_delete=models.PROTECT)
#     session = models.ForeignKey(Session, on_delete=models.PROTECT)
#     semester = models.ForeignKey(SemesterAndYear, on_delete=models.PROTECT)
#     INACTIVE = 0
#     ACTIVE = 1
#     STATUS_CHOICES = (
#         (INACTIVE, 'Inactive'),
#         (ACTIVE, 'Active'),
#     )
#     status = models.SmallIntegerField(choices=STATUS_CHOICES)
#     created_by = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
# """
# # class StudentClassRoomPeriod(models.Model):
# #     id = models.AutoField(primary_key=True)
# #     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
# #     student = models.ForeignKey(Student, on_delete=models.PROTECT)
# #     class_room_period = models.ForeignKey(ClassRoomPeriod, on_delete=models.PROTECT)
# #     INACTIVE = 0
# #     ACTIVE = 1
# #     STATUS_CHOICES = (
# #         (INACTIVE, 'Inactive'),
# #         (ACTIVE, 'Active'),
# #     )
# #     status = models.SmallIntegerField(choices=STATUS_CHOICES)
# #     created_by = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
# #     is_deleted = models.BooleanField(default=False)
# #     created_at = models.DateTimeField(auto_now_add=True)
# #     updated_at = models.DateTimeField(auto_now=True)
#
#
# class StudentAttendance(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     Student = models.ForeignKey(Student, on_delete=models.PROTECT)
#     year = models.IntegerField()
#     month = models.IntegerField()
#     date = models.IntegerField()
#     attendance = models.IntegerField()
#     semester = models.ForeignKey(SemesterAndYear, on_delete=models.PROTECT)
#
#     INACTIVE = 0
#     ACTIVE = 1
#     STATUS_CHOICES = (
#         (INACTIVE, 'Inactive'),
#         (ACTIVE, 'Active'),
#     )
#     status = models.SmallIntegerField(choices=STATUS_CHOICES)
#     created_by = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#
# class StudentLeave(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     Student = models.ForeignKey(Student, on_delete=models.PROTECT)
#     leave_start = models.DateField()
#     leave_end = models.DateField()
#     total_leave = models.CharField(max_length=50)
#     subject = models.CharField(max_length=255)
#     message = models.TextField()
#     INACTIVE = 0
#     ACTIVE = 1
#     STATUS_CHOICES = (
#         (INACTIVE, 'Inactive'),
#         (ACTIVE, 'Active'),
#     )
#     status = models.SmallIntegerField(choices=STATUS_CHOICES)
#     created_by = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#
