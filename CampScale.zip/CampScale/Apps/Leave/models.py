from django.db import models
"""
from Apps.Employee.models import Employee
from Apps.Student.models import Student


class Leave(models.Model):
    id = models.AutoField(primary_key=True)
    student_id = models.ForeignKey(Student, null=True, on_delete=models.CASCADE)
    employee_id = models.ForeignKey(Employee, null=True, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    message = models.TextField()
    status = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    # its an prototype
    def get_student_leave(self):
        # define algorithm that check
        if self.employee_id == Null:
            self.id = "something"
            self.student_id = "something"
            self.start_date = "something"
            self.end_date = "something"
            self.message = "something"

        return self.id, self.employee_id, self.start_date, self.end_date, self.message

    def get_employee_leave(self):
        # define algorithm that check
        if self.student_id == Null:
            self.id = "something"
            self.employee_id = "something"
            self.start_date = "something"
            self.end_date = "something"
            self.message = "something"

        return self.id, self.employee_id, self.start_date, self.end_date, self.message

"""

