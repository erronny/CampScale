from django.urls import path
from . import views

app_name = 'Leave'
urlpatterns = [

    path('admin/leave/', views.index, name="leave"),
    path('admin/create_leave/', views.add, name="create_leave"),
    path('admin/change_leave/', views.change, name="change_leave"),
    path('admin/view_leave/', views.index, name="view_leave"),

]