# from django.db import models
#
# from Apps.Organization.models import Organization, Department, ClassRoomPeriod
# from django.contrib.auth import get_user_model
#
# User = get_user_model()
#
#
# class EmployeeType(models.Model):
#     id = models.AutoField(primary_key=True)
#     # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     type = models.CharField(max_length=255)
#     status = models.IntegerField(default=1)
#     # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#
# class Employee(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization_id = models.ForeignKey(Organization, on_delete=models.CASCADE)
#     first_name = models.CharField(max_length=255)
#     middle_name = models.CharField(max_length=255, blank=True, null=True)
#     last_name = models.CharField(max_length=255)
#     father_name = models.CharField(max_length=255)
#     mother_name = models.CharField(max_length=255)
#     dob = models.DateField()
#     gender = models.CharField(max_length=255)
#     email = models.EmailField()
#     mobile_no = models.IntegerField()
#     joining_date = models.DateField()
#     aadhar = models.CharField(max_length=12)
#     employee_code = models.CharField(max_length=255)
#     type = models.ForeignKey(EmployeeType, on_delete=models.PROTECT, default=1)
#     profile_pic = models.ImageField(blank=True, null=True, upload_to='student_image')
#     district = models.CharField(max_length=255)
#     state = models.CharField(max_length=255)
#     postal_code = models.IntegerField()
#     current_address = models.TextField(max_length=255)
#     permanent_address = models.TextField(max_length=255)
#     status = models.IntegerField(default=1)
#     # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#     def __str__(self):
#         return self.first_name
#
#
# class EmployeeRoom(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     employee_room_name = models.CharField(max_length=255)
#     employee = models.ForeignKey(Employee, on_delete=models.PROTECT,
#                                  help_text="It explain about who is head of staff room")
#     member_list = models.TextField(help_text="list all the member who allowed in staff room. e.g abc, pqr")
#     total_member = models.IntegerField()
#
#     status = models.IntegerField(default=1)
#     # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#
# class DepartmentMember(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     department = models.ForeignKey(Department, on_delete=models.PROTECT)
#     employee = models.ForeignKey(Employee, on_delete=models.PROTECT)
#
#     status = models.IntegerField(default=1)
#     # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#     def __str__(self):
#         return self.employee
#
#     @property
#     def get_department_member(self):
#         department_details = "This class contains various departments of School like English, Tamil,Art, etc."
#         return department_details
#
#
# class EmployeeClassRoomPeriod(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     employee = models.ForeignKey(Employee, on_delete=models.PROTECT)
#     class_room_period = models.ForeignKey(ClassRoomPeriod, on_delete=models.PROTECT)
#
#     status = models.IntegerField(default=1)
#     # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#
# class EmployeeAttendance(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     employee = models.ForeignKey(Employee, on_delete=models.PROTECT)
#     year = models.IntegerField()
#     month = models.IntegerField()
#     date = models.IntegerField()
#     attendance = models.IntegerField()
#     time_in = models.TimeField()
#     time_out = models.TimeField()
#     total_hour = models.TimeField()
#
#     status = models.IntegerField(default=1)
#     # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
#
# class EmployeeLeave(models.Model):
#     id = models.AutoField(primary_key=True)
#     organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
#     employee = models.ForeignKey(Employee, on_delete=models.PROTECT)
#     leave_start = models.DateField()
#     leave_end = models.DateField()
#     total_leave = models.CharField(max_length=50)
#     subject = models.CharField(max_length=255)
#     message = models.TextField()
#
#     status = models.IntegerField(default=1)
#     # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
#     is_deleted = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
#
