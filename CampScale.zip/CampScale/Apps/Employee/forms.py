from django import forms
from .models import *


class EmployeeTypeForm(forms.ModelForm):
    type = forms.CharField(label="Employee Type", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))

    class Meta:
        model = EmployeeType
        fields = ['type']

    def clean(self):
        cleaned_data = super(EmployeeTypeForm, self).clean()
        type = cleaned_data.get("type")
        return cleaned_data


class EmployeeForm(forms.ModelForm):
    EMPLOYEE_CHOICE = [
        ('Staff', 'Staff'),
        ('Faculty', 'Faculty')
    ]
    type = forms.CharField(label="Employee Type", required=True, widget=forms.Select(choices=EMPLOYEE_CHOICE,
                                                                                     attrs={'class': 'form-control'}))
    first_name = forms.CharField(label="First Name", required=True, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))
    middle_name = forms.CharField(label="Middle Name", required=False, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))
    last_name = forms.CharField(label="Last Name", required=True, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))
    father_name = forms.CharField(label="Father Name", required=True, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))
    mother_name = forms.CharField(label="Mother Name", required=True, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))
    dob = forms.DateField(label="Date of birth", required=True, widget=forms.DateInput(
        attrs={'type': 'date', 'class': 'form-control'}))
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female')
    ]
    gender = forms.CharField(label="Gender", required=True, widget=forms.Select(choices=GENDER_CHOICES,
                                                                                attrs={'class': 'form-control'}))
    email = forms.EmailField(label="Email", required=True, widget=forms.EmailInput(attrs={'class': 'form-control'}))
    mobile_no = forms.IntegerField(label="Mobile No", required=True, widget=forms.NumberInput(
        attrs={'min': '10', 'max': '10', 'class': 'form-control'}))
    joining_date = forms.CharField(label="Joining Date", required=True, widget=forms.TextInput(
        attrs={'class': 'form-control'}))
    aadhar = forms.CharField(label="Aadhar No", required=True, widget=forms.TextInput(
        attrs={'min': '12', 'max': '12', 'class': 'form-control'}))
    employee_code = forms.CharField(label="Employee Code", required=True, widget=forms.TextInput(
        attrs={'class': 'form-control'}))

    district = forms.CharField(label="District", required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    state = forms.CharField(label="State", required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    postal_code = forms.IntegerField(label="Postal Code", required=True, widget=forms.NumberInput(
        attrs={'min': '6', 'max': '6', 'class': 'form-control'}))
    current_address = forms.CharField(label="Current Address", required=True, widget=forms.Textarea(
        attrs={'class': 'form-control'}))
    permanent_address = forms.CharField(label="Permanent Address", required=True, widget=forms.Textarea(
        attrs={'class': 'form-control'}))

    class Meta:
        model = Employee
        fields = ['first_name', 'last_name', 'middle_name', 'father_name', 'mother_name', 'dob', 'gender',
                  'email', 'mobile_no', 'aadhar', 'employee_code', 'district', 'state', 'postal_code',
                  'current_address', 'permanent_address', 'joining_date']

    def clean(self):
        cleaned_data = super(EmployeeForm, self).clean()
        first_name = cleaned_data.get("first_name")
        last_name = cleaned_data.get("last_name")
        middle_name = cleaned_data.get("middle_name")
        father_name = cleaned_data.get("father_name")
        mother_name = cleaned_data.get("mother_name")
        dob = cleaned_data.get("dob")
        gender = cleaned_data.get("gender")
        email = cleaned_data.get("email")
        mobile_no = cleaned_data.get("mobile_no")
        aadhar = cleaned_data.get("aadhar")
        employee_code = cleaned_data.get("employee_code")
        district = cleaned_data.get("district")
        state = cleaned_data.get("state")
        postal_code = cleaned_data.get("postal_code")
        current_address = cleaned_data.get("current_address")
        permanent_address = cleaned_data.get("permanent_address")
        joining_date = cleaned_data.get("joining_date")
        return cleaned_data


class EmployeeRoomForm(forms.ModelForm):
    employee_room_name = forms.CharField(label="Room Name", required=True, widget=forms.TextInput(
        attrs={'class': 'form-control'}))
    CHOICE_EMPLOYEE = [
        ('Albert', 'albert')
    ]
    employee = forms.CharField(label="Employee", required=True, widget=forms.Select(
        attrs={'class': 'form-control'}))
    member_list = forms.CharField(label="Member List", required=True, widget=forms.Textarea(
        attrs={'class': 'form-control'}))
    total_member = forms.IntegerField(label="Total Member", required=True, widget=forms.NumberInput(
        attrs={'class': 'form-control'}))

    class Meta:
        model = EmployeeRoom
        fields = ['employee_room_name', 'employee', 'member_list', 'total_member']

    def clean(self):
        cleaned_data = super(EmployeeRoomForm, self).clean()
        employee_room_name = cleaned_data.get("employee_room_name")
        employee = cleaned_data.get("employee")
        member_list = cleaned_data.get("member_list")
        total_member = cleaned_data.get("total_member")
        return cleaned_data


class DepartmentMemberForm(forms.ModelForm):
    CHOICE_DEPARTMENT = [
        ('MBA', 'MBA')
    ]
    department = forms.CharField(label="Department", required=True, widget=forms.Select(choices=CHOICE_DEPARTMENT,
                                                                                        attrs={
                                                                                            'class': 'form-control'}))
    CHOICE_EMPLOYEE = [
        ('Albert', 'albert')
    ]
    employee = forms.CharField(label="Employee", required=True, widget=forms.Select(choices=CHOICE_EMPLOYEE,
                                                                                    attrs={'class': 'form-control'}))

    class Meta:
        model = DepartmentMember
        fields = ['department', 'employee']

    def clean(self):
        cleaned_data = super(DepartmentMemberForm, self).clean()
        department = cleaned_data.get("department")
        employee = cleaned_data.get("employee")
        return cleaned_data


class EmployeeClassRoomPeriodform(forms.ModelForm):
    PERIOD = [
        ('MBA', 'MBA')
    ]
    class_room_period = forms.CharField(label="Class Room Period", required=True, widget=forms.Select(choices=PERIOD,
                                                                                    attrs={'class': 'form-control'}))
    CHOICE_EMPLOYEE = [
        ('Albert', 'albert')
    ]
    employee = forms.CharField(label="Employee", required=True, widget=forms.Select(choices=CHOICE_EMPLOYEE,
                                                                                    attrs={'class': 'form-control'}))

    class Meta:
        model = EmployeeClassRoomPeriod
        fields = ['class_room_period', 'employee']

    def clean(self):
        cleaned_data = super(EmployeeClassRoomPeriodform, self).clean()
        class_room_period = cleaned_data.get("class_room_period")
        employee = cleaned_data.get("employee")
        return cleaned_data


class EmployeeAttendanceForm(forms.ModelForm):
    CHOICE_EMPLOYEE = [
        ('Albert', 'albert')
    ]
    employee = forms.CharField(label="Employee", required=True, widget=forms.Select(choices=CHOICE_EMPLOYEE,
                                                                                    attrs={'class': 'form-control'}))
    year = forms.IntegerField(label="Year", required=True, widget=forms.NumberInput(
                                                                                    attrs={'class': 'form-control'}))
    month = forms.IntegerField(label="month", required=True, widget=forms.NumberInput(
                                                                                    attrs={'class': 'form-control'}))
    date = forms.IntegerField(label="Date", required=True, widget=forms.NumberInput(
                                                                                    attrs={'class': 'form-control'}))
    attendance = forms.CharField(label="Attendance", required=True, widget=forms.TextInput(
                                                                                    attrs={'class': 'form-control'}))
    time_in = forms.TimeField(label="Attendance", required=True, widget=forms.TimeInput(
                                                                                    attrs={'class': 'form-control'}))
    time_out = forms.TimeField(label="Attendance", required=True, widget=forms.TimeInput(
                                                                                    attrs={'class': 'form-control'}))

    class Meta:
        model = EmployeeAttendance
        fields = ['employee', 'year', 'month', 'date', 'attendance', 'time_in', 'time_out']

    def clean(self):
        cleaned_data = super(EmployeeAttendanceForm, self).clean()
        employee = cleaned_data.get("employee")
        year = cleaned_data.get("year")
        month = cleaned_data.get("month")
        date = cleaned_data.get("date")
        attendance = cleaned_data.get("attendance")
        time_in = cleaned_data.get("time_in")
        time_out = cleaned_data.get("time_out")
        return cleaned_data


class EmployeeLeaveForm(forms.ModelForm):
    CHOICE_EMPLOYEE = [
        ('Albert', 'albert')
    ]
    employee = forms.CharField(label="Employee", required=True, widget=forms.Select(choices=CHOICE_EMPLOYEE,
                                                                                    attrs={'class': 'form-control'}))
    leave_start = forms.DateField(label="Year", required=True, widget=forms.DateInput(
        attrs={'class': 'form-control'}))
    leave_end = forms.DateField(label="month", required=True, widget=forms.DateInput(
        attrs={'class': 'form-control'}))
    total_leave = forms.CharField(label="Date", required=True, widget=forms.TextInput(
        attrs={'class': 'form-control'}))
    subject = forms.CharField(label="Subject", required=True, widget=forms.TextInput(
        attrs={'class': 'form-control'}))
    message = forms.CharField(label="Message", required=True, widget=forms.Textarea(
        attrs={'class': 'form-control'}))

    class Meta:
        model = EmployeeLeave
        fields = ['employee', 'leave_start', 'leave_end', 'total_leave', 'subject', 'message']

    def clean(self):
        cleaned_data = super(EmployeeLeaveForm, self).clean()
        employee = cleaned_data.get("employee")
        leave_start = cleaned_data.get("leave_start")
        leave_end = cleaned_data.get("leave_end")
        total_leave = cleaned_data.get("total_leave")
        subject = cleaned_data.get("subject")
        message = cleaned_data.get("message")
        return cleaned_data
