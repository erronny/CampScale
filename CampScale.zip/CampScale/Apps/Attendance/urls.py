from django.urls import path
from . import views

app_name = 'Attendance'
urlpatterns = [
    # path('', views.index, name="home"),
    path('admin/attendance/', views.index, name="attendance"),
    path('admin/create_attendance/', views.add, name="create_attendance"),
    path('admin/change_attendance/', views.change, name="change_attendance"),
    path('admin/view_attendance/', views.index, name="view_attendance"),

]