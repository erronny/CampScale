from django.db import models

"""
class StudentAttendance(models.Model):
    pass


class EmployeeAttendance(models.Model):
    pass

"""