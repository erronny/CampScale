from django import forms
from .models import *


# from .models import Organization, Session, Subject, SemesterAndYear, Stationery, Course, ClassRoom, ClassRoomPeriod, \
#     ClassInventory, Canteen, NoticeBoard, Inventory, LabInventory, Lab, Auditorium, Department


class OrganizationCreationFrom(forms.ModelForm):
    org_name = forms.CharField(required=True, label="Name", widget=forms.TextInput(attrs={'type': 'text',

                                                                                          'value': "",
                                                                                          'class': 'form-control'}))
    org_code = forms.CharField(required=True, label="Code", widget=forms.TextInput(attrs={'type': 'text',
                                                                                          'value': "",
                                                                                          'class': 'form-control'}))
    org_email = forms.EmailField(required=True, label="email", widget=forms.EmailInput(attrs={'type': 'email',
                                                                                              'value': "",
                                                                                              'class': 'form-control'}))
    org_representative = forms.CharField(required=True, label="Representative",
                                         widget=forms.TextInput(attrs={'type': 'text',
                                                                       'value': "",
                                                                       'class': 'form-control'}))
    org_type = forms.CharField(required=True, label="Type", widget=forms.TextInput(attrs={'type': 'text',
                                                                                          'value': "",
                                                                                          'class': 'form-control'}))
    org_level = forms.CharField(required=True, label="Level", widget=forms.TextInput(attrs={'type': 'text',
                                                                                            'value': "",
                                                                                            'class': 'form-control'}))
    org_affiliation = forms.CharField(required=True, label="Affiliation", widget=forms.TextInput(
        attrs={'type': 'text',
               'value': "", 'class': 'form-control'}))
    org_mobile_no = forms.IntegerField(required=True, label="Mobile No",
                                       widget=forms.NumberInput(attrs={'type': 'number',
                                                                       # 'min': 10, 'max': 10,
                                                                       'class': 'form-control'}))
    org_phone_no = forms.CharField(required=True, max_length=10, label="Contact No",
                                   widget=forms.NumberInput(attrs={'type': 'number',
                                                                   # 'min': '10', 'max': '10',
                                                                   'class': 'form-control'}))
    org_district = forms.CharField(required=True, label="District", widget=forms.TextInput(attrs={'type': 'text',
                                                                                                  'value': "",
                                                                                                  'class': 'form-control'}))
    org_state = forms.CharField(required=True, label="State", widget=forms.TextInput(attrs={'type': 'text',
                                                                                            'value': "",
                                                                                            'class': 'form-control'}))
    org_postal_code = forms.IntegerField(required=True, label="Postal Code",
                                         widget=forms.NumberInput(attrs={'type': 'text',
                                                                         # 'min': '6', 'max': '6',
                                                                         'class': 'form-control'}))
    org_address = forms.CharField(required=True, label="Address", widget=forms.TextInput(attrs={'type': 'text',
                                                                                                'value': "",
                                                                                                'class': 'form-control'}))

    class Meta:
        model = Organization
        # exclude = ()
        fields = [
            'org_name',
            'org_code',
            'org_email',
            'org_representative',
            'org_type',
            'org_level',
            'org_affiliation',
            'org_mobile_no',
            'org_phone_no',
            'org_district',
            'org_state',
            'org_postal_code',
            'org_address'
            # 'status'
        ]

    def clean(self):
        cleaned_data = super(OrganizationCreationFrom, self).clean()
        org_name = cleaned_data.get("org_name")
        org_code = cleaned_data.get("org_code")
        org_representative = cleaned_data.get("org_representative")
        org_email = cleaned_data.get("org_email")
        org_phone_no = cleaned_data.get("org_phone_no")
        org_mobile_no = cleaned_data.get("org_mobile_no")
        org_type = cleaned_data.get("org_type")
        org_level = cleaned_data.get("org_level")
        org_district = cleaned_data.get("org_district")
        org_state = cleaned_data.get("org_state")
        org_address = cleaned_data.get("org_address")
        status = cleaned_data.get("status")
        org_affiliation = cleaned_data.get("org_affiliation")
        org_postal_code = cleaned_data.get("org_postal_code")

        return cleaned_data


class OrganizationUpdationFrom(forms.ModelForm):
    org_name = forms.CharField(required=True, label="Name", widget=forms.TextInput(attrs={'type': 'text',

                                                                                          'value': "",
                                                                                          'class': 'form-control'}))
    org_code = forms.CharField(required=True, label="Code", widget=forms.TextInput(attrs={'type': 'text',
                                                                                          'value': "",
                                                                                          'class': 'form-control'}))
    org_email = forms.EmailField(required=True, label="email", widget=forms.EmailInput(attrs={'type': 'email',
                                                                                              'value': "",
                                                                                              'class': 'form-control'}))
    org_representative = forms.CharField(required=True, label="Representative",
                                         widget=forms.TextInput(attrs={'type': 'text',
                                                                       'value': "",
                                                                       'class': 'form-control'}))
    org_type = forms.CharField(required=True, label="Type", widget=forms.TextInput(attrs={'type': 'text',
                                                                                          'value': "",
                                                                                          'class': 'form-control'}))
    org_level = forms.CharField(required=True, label="Level", widget=forms.TextInput(attrs={'type': 'text',
                                                                                            'value': "",
                                                                                            'class': 'form-control'}))
    org_affiliation = forms.CharField(required=True, label="Affiliation", widget=forms.TextInput(
        attrs={'type': 'text',
               'value': "", 'class': 'form-control'}))
    org_mobile_no = forms.IntegerField(required=True, label="Mobile No",
                                       widget=forms.NumberInput(attrs={'type': 'number',
                                                                       # 'min': 10, 'max': 10,
                                                                       'class': 'form-control'}))
    org_phone_no = forms.CharField(required=True, label="Contact No",
                                   widget=forms.NumberInput(attrs={
                                       'minlength': 10, 'maxlength': 10,
                                       'class': 'form-control'}))
    org_district = forms.CharField(required=True, label="District", widget=forms.TextInput(attrs={'type': 'text',
                                                                                                  'value': "",
                                                                                                  'class': 'form-control'}))
    org_state = forms.CharField(required=True, label="State", widget=forms.TextInput(attrs={'type': 'text',
                                                                                            'value': "",
                                                                                            'class': 'form-control'}))
    org_postal_code = forms.IntegerField(required=True, label="Postal Code",
                                         widget=forms.NumberInput(attrs={'type': 'text',
                                                                         # 'min': '6', 'max': '6',
                                                                         'class': 'form-control'}))
    org_address = forms.CharField(required=True, label="Address", widget=forms.TextInput(attrs={'type': 'text',
                                                                                                'value': "",
                                                                                                'class': 'form-control'}))
    INACTIVE = False
    ACTIVE = True
    STATUS_CHOICES = [
        (ACTIVE, 'Active'),
        (INACTIVE, 'Inactive')

    ]
    status = forms.CharField(required=True, label="Status", widget=forms.Select(choices=STATUS_CHOICES,
                                                                                attrs={'class': 'form-control'}))

    class Meta:
        model = Organization
        # exclude = ()
        fields = [
            'org_name',
            'org_code',
            'org_email',
            'org_representative',
            'org_type',
            'org_level',
            'org_affiliation',
            'org_mobile_no',
            'org_phone_no',
            'org_district',
            'org_state',
            'org_postal_code',
            'org_address',
            'status'
        ]

    def clean(self):
        cleaned_data = super(OrganizationUpdationFrom, self).clean()
        org_name = cleaned_data.get("org_name")
        org_code = cleaned_data.get("org_code")
        org_representative = cleaned_data.get("org_representative")
        org_email = cleaned_data.get("org_email")
        org_phone_no = cleaned_data.get("org_phone_no")
        org_mobile_no = cleaned_data.get("org_mobile_no")
        org_type = cleaned_data.get("org_type")
        org_level = cleaned_data.get("org_level")
        org_district = cleaned_data.get("org_district")
        org_state = cleaned_data.get("org_state")
        org_address = cleaned_data.get("org_address")
        status = cleaned_data.get("status")
        org_affiliation = cleaned_data.get("org_affiliation")
        org_postal_code = cleaned_data.get("org_postal_code")
        status = cleaned_data.get("status")

        return cleaned_data


#################################

class CourseForm(forms.ModelForm):
    course_name = forms.CharField(label="Course Name",
                                  required=True, widget=forms.TextInput(
            attrs={'type': 'text', 'class': 'form-control'
                   }))
    course_code = forms.CharField(label="Course Code",
                                  required=True, widget=forms.TextInput(
            attrs={'type': 'text', 'class': 'form-control'
                   }))
    course_type = forms.CharField(label="Course Type", required=True,
                                  widget=forms.TextInput(attrs={
                                      'type': 'text', 'class': 'form-control'
                                  }))
    course_duration = forms.IntegerField(label="Course Duration", required=True,
                                         widget=forms.NumberInput(attrs={
                                             'type': 'number', 'class': 'form-control'
                                         }))
    course_available_seats = forms.IntegerField(label="Available Seat", required=True,
                                                widget=forms.NumberInput(attrs={
                                                    'type': 'number', 'class': 'form-control'
                                                }))

    course_fees = forms.IntegerField(label="Course Fee", required=True,
                                     widget=forms.NumberInput(attrs={'type': 'number', 'class': 'form-control'}))

    class Meta:
        model = Course
        fields = ['course_name', 'course_code', 'course_fees', 'course_duration', 'course_available_seats']

    def clean(self):
        cleaned_data = super(CourseForm, self).clean()
        course_name = cleaned_data.get("course_name")
        course_code = cleaned_data.get("course_code")
        course_type = cleaned_data.get("course_type")
        course_duration = cleaned_data.get("course_duration")
        course_fees = cleaned_data.get("course_fees")
        course_available_seats = cleaned_data.get("course_available_seats")
        return cleaned_data


class SemesterForm(forms.ModelForm):
    semester = forms.CharField(label="Semester name", required=True, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))

    class Meta:
        model = SemesterAndYear
        fields = ['semester']


class SubjectForm(forms.ModelForm):
    COURSE_CHOIE = [
        ('B.Tech', 'B.tech'),
        ('M.Tech', 'M.TECH')
    ]
    course = forms.CharField(label="Course Name", required=True, widget=forms.Select(choices=COURSE_CHOIE,
                                                                                     attrs={'class': 'form-control'}))
    subject_name = forms.CharField(label="Subject Name", required=True, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))
    subject_code = forms.CharField(label="Subject Code", required=True, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))
    subject_min_marks = forms.IntegerField(label="Subject Name", required=True, widget=forms.NumberInput(
        attrs={'type': 'number', 'min': '1', 'max': '3', 'class': 'form-control'}))
    subject_max_marks = forms.IntegerField(label="Subject Name", required=True, widget=forms.NumberInput(
        attrs={'type': 'number', 'min': '1', 'max': '3', 'class': 'form-control'}))
    SEMESTER_CHOICE = [
        ('sem1/year2', 'sem1/Year2'),
        ('sem2/year2', 'sem2/Year2')
    ]
    semester = forms.CharField(label="Course Name", required=True, widget=forms.Select(choices=SEMESTER_CHOICE,
                                                                                       attrs={'class': 'form-control'}))

    class Meta:
        model = Subject
        fields = ['subject_name', 'subject_code', 'semester', 'course', 'subject_min_marks', 'subject_max_marks']

    def clean(self):
        cleaned_data = super(SubjectForm, self).clean()
        subject_name = cleaned_data.get("subject_name")
        subject_code = cleaned_data.get("subject_code")
        semester = cleaned_data.get("semester")
        course = cleaned_data.get("course")
        subject_min_marks = cleaned_data.get("subject_min_marks")
        subject_max_marks = cleaned_data.get("subject_max_marks")
        return cleaned_data


class CanteenForm(forms.ModelForm):
    product = forms.CharField(label="Product", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    price = forms.IntegerField(label="Price", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))
    level = forms.CharField(label="Level", required=False, widget=forms.TextInput(
        attrs={'type': 'text', 'class': 'form-control'}))

    class Meta:
        model = Canteen
        fields = ['product', 'price', 'level']

    def clean(self):
        cleaned_data = super(CanteenForm, self).clean()
        product = cleaned_data.get("product")
        price = cleaned_data.get("price")
        level = cleaned_data.get("level")
        return cleaned_data


class StationeryForm(forms.ModelForm):
    product = forms.CharField(label="Product", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    price = forms.IntegerField(label="Price", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))

    class Meta:
        model = Stationery
        fields = ['product', 'price']

    def clean(self):
        cleaned_data = super(StationeryForm, self).clean()
        product = cleaned_data.get("product")
        price = cleaned_data.get("price")
        return cleaned_data


class SessionForm(forms.ModelForm):
    session_year = forms.CharField(label="Session", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))

    class Meta:
        model = Session
        fields = ['session_year']

    def clean(self):
        cleaned_data = super(SessionForm, self).clean()
        session_year = cleaned_data.get("session_year")
        return cleaned_data


class DepartmentForm(forms.ModelForm):
    department_name = forms.CharField(label="Department Name", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    incharge_name = forms.CharField(label="Incharge Name", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))

    class Meta:
        model = Department
        fields = ['department_name', 'incharge_name']

    def clean(self):
        cleaned_data = super(DepartmentForm, self).clean()
        department_name = cleaned_data.get("department_name")
        incharge_name = cleaned_data.get("incharge_name")
        return cleaned_data


class NoticeBoardForm(forms.ModelForm):
    notice = forms.CharField(label="Notice", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    level = forms.CharField(label="Level", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    description = forms.CharField(label="Description", required=True, widget=forms.TextInput(attrs={
        'type': 'textarea', 'class': 'form-control'}))

    class Meta:
        model = NoticeBoard
        fields = ['notice', 'description', 'level']

    def clean(self):
        cleaned_data = super(NoticeBoardForm, self).clean()
        notice = cleaned_data.get("notice")
        level = cleaned_data.get("level")
        description = cleaned_data.get("description")
        return cleaned_data


class ClassRoomForm(forms.ModelForm):
    class_name = forms.CharField(label="Class Name", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))

    class Meta:
        model = ClassRoom
        fields = ['class_name']

    def clean(self):
        cleaned_data = super(ClassRoomForm, self).clean()
        class_name = cleaned_data.get("class_name")
        return cleaned_data


class ClassRoomPeriodForm(forms.ModelForm):
    total_time = forms.CharField(label="Total Time", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    time_start = forms.CharField(label="Time Start", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    time_end = forms.CharField(label="Time End", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    SUBJECT_CHOICES = [
        ('Physics', 'Physics'),
        ('Chemistry', 'Chemistry'),
        ('Chemistry', 'Chemistry'),
    ]
    # class = forms.CharField(label="Notice", required=True, widget=forms.Select(choices=SUBJECT_CHOICES, attrs={
    #     'type': 'text', 'class': 'form-control'}))
    # SUBJECT_CHOICES = [
    #     ('Physics', 'Physics'),
    #     ('Chemistry', 'Chemistry'),
    # ]
    subject = forms.CharField(label="Subject", required=True, widget=forms.Select(choices=SUBJECT_CHOICES, attrs={
        'type': 'text', 'class': 'form-control'}))

    class Meta:
        model = ClassRoomPeriod
        fields = ['total_time', 'time_start', 'time_end', 'subject']

    def clean(self):
        cleaned_data = super(ClassRoomPeriodForm, self).clean()
        class_name = cleaned_data.get("class_name")
        return cleaned_data


class AuditoriumForm(forms.ModelForm):
    total_seats = forms.IntegerField(label="Total seats", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))
    seats_occupied = forms.IntegerField(label="Seats Occupied", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))
    event_name = forms.CharField(label="Event Name", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    event_date = forms.DateField(label="Event Date", required=True, widget=forms.DateInput(attrs={
        'type': 'date', 'class': 'form-control'}))
    event_time = forms.TimeField(label="Event Time", required=True, widget=forms.TimeInput(attrs={
        'type': 'time', 'class': 'form-control'}))

    class Meta:
        model = Auditorium
        fields = ['total_seats', 'seats_occupied', 'event_name', 'event_date', 'event_time']

    def clean(self):
        cleaned_data = super(AuditoriumForm, self).clean()
        total_seats = cleaned_data.get("total_seats")
        seats_occupied = cleaned_data.get("seats_occupied")
        event_name = cleaned_data.get("event_name")
        event_date = cleaned_data.get("event_date")
        event_time = cleaned_data.get("event_time")
        return cleaned_data


class LabForm(forms.ModelForm):
    lab_name = forms.CharField(label="Lab Name", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    lab_level = forms.CharField(label="Lab Level", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))

    class Meta:
        model = Lab
        fields = ['lab_name', 'lab_level']

    def clean(self):
        cleaned_data = super(LabForm, self).clean()
        lab_name = cleaned_data.get("lab_name")
        lab_level = cleaned_data.get("lab_level")
        return cleaned_data


class InventoryForm(forms.ModelForm):
    inventory_name = forms.CharField(label="Lab Name", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    inventory_level = forms.CharField(label="Lab Level", required=True, widget=forms.TextInput(attrs={
        'type': 'text', 'class': 'form-control'}))
    no_of_inventory = forms.IntegerField(label="Notice", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))

    class Meta:
        model = Inventory
        fields = ['inventory_name', 'inventory_level', 'no_of_inventory']

    def clean(self):
        cleaned_data = super(InventoryForm, self).clean()
        inventory_name = cleaned_data.get("inventory_name")
        inventory_level = cleaned_data.get("inventory_level")
        no_of_inventory = cleaned_data.get("no_of_inventory")
        return cleaned_data


class LabInventoryForm(forms.ModelForm):
    lab = forms.IntegerField(label="Notice", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))
    inventory = forms.IntegerField(label="Notice", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))
    count_of_lab_inventory = forms.IntegerField(label="Notice", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))

    class Meta:
        model = LabInventory
        fields = ['lab', 'inventory', 'count_of_lab_inventory']

    def clean(self):
        cleaned_data = super(LabInventoryForm, self).clean()
        lab = cleaned_data.get("lab")
        inventory = cleaned_data.get("inventory")
        count_of_lab_inventory = cleaned_data.get("count_of_lab_inventory")
        return cleaned_data


class ClassInventoryForm(forms.ModelForm):
    class_room = forms.IntegerField(label="Notice", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))
    inventory = forms.IntegerField(label="Notice", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))
    count_of_class_inventory = forms.IntegerField(label="Notice", required=True, widget=forms.NumberInput(attrs={
        'type': 'number', 'class': 'form-control'}))

    class Meta:
        model = ClassInventory
        fields = ['class_room', 'inventory', 'count_of_class_inventory']

    def clean(self):
        cleaned_data = super(ClassInventoryForm, self).clean()
        class_room = cleaned_data.get("class_room")
        inventory = cleaned_data.get("inventory")
        count_of_class_inventory = cleaned_data.get("count_of_class_inventory")
        return cleaned_data
