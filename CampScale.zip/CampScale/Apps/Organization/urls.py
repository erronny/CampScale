from django.urls import path
from . import views

app_name = 'Organization'
urlpatterns = [

    path('admin/organization/', views.organization_list, name="organization"),
    path('admin/create_organization/', views.add_organization, name="create_organization"),
    path('admin/change_organization/<id>', views.change_organization, name="change_organization"),
    path('admin/view_organization/<id>', views.view_organization, name="view_organization"),
    path('admin/enable_organization/<id>', views.enable_organization, name="enable_organization"),
    path('admin/disable_organization/<id>', views.disable_organization, name="disable_organization"),
    path('admin/trash_organization/<id>', views.trash_organization, name="trash_organization"),
    path('admin/restore_organization/<id>', views.restore_organization, name="restore_organization"),
    path('admin/delete_organization/<id>', views.delete_organization, name="delete_organization"),

    path('admin/course/', views.course_list, name="course"),
    path('admin/create_course/', views.add_course, name="create_course"),
    path('admin/change_course/', views.change_course, name="change_course"),
    path('admin/view_course/', views.view_course, name="view_course"),
    path('admin/delete_course/', views.delete_course, name="delete_course"),

    path('admin/semester_year/', views.semester_year_list, name="semester_year"),
    path('admin/create_semester_year/', views.add_semester_year, name="create_semester_year"),
    path('admin/change_semester_year/', views.change_semester_year, name="change_semester_year"),
    path('admin/view_semester_year/', views.view_semester_year, name="view_semester_year"),
    path('admin/delete_semester_year/', views.delete_semester_year, name="delete_semester_year"),

    path('admin/subject/', views.subject_list, name="subject"),
    path('admin/create_subject/', views.add_subject, name="create_subject"),
    path('admin/change_subject/', views.change_subject, name="change_subject"),
    path('admin/view_subject/', views.view_subject, name="view_subject"),
    path('admin/delete_subject/', views.delete_subject, name="delete_subject"),

    path('admin/canteen/', views.canteen_list, name="canteen"),
    path('admin/create_canteen/', views.add_canteen, name="create_canteen"),
    path('admin/change_canteen/', views.change_canteen, name="change_canteen"),
    path('admin/view_canteen/', views.view_canteen, name="view_canteen"),
    path('admin/delete_canteen/', views.delete_canteen, name="delete_canteen"),

    path('admin/stationery/', views.stationery_list, name="stationery"),
    path('admin/create_stationery/', views.add_stationery, name="create_stationery"),
    path('admin/change_stationery/', views.change_stationery, name="change_stationery"),
    path('admin/view_stationery/', views.view_stationery, name="view_stationery"),
    path('admin/delete_stationery/', views.delete_stationery, name="delete_stationery"),

    path('admin/session/', views.session_list, name="session"),
    path('admin/create_session/', views.add_session, name="create_session"),
    path('admin/change_session/', views.change_session, name="change_session"),
    path('admin/view_session/', views.view_session, name="view_session"),
    path('admin/delete_session/', views.delete_session, name="delete_session"),

    path('admin/department/', views.department_list, name="department"),
    path('admin/create_department/', views.add_department, name="create_department"),
    path('admin/change_department/', views.change_department, name="change_department"),
    path('admin/view_department/', views.view_department, name="view_department"),
    path('admin/delete_department/', views.delete_department, name="delete_department"),

    path('admin/notice_board/', views.noticeboard_list, name="notice_board"),
    path('admin/create_notice_board/', views.add_noticeboard, name="create_notice_board"),
    path('admin/change_notice_board/', views.change_noticeboard, name="change_notice_board"),
    path('admin/view_notice_board/', views.view_noticeboard, name="view_notice_board"),
    path('admin/delete_notice_board/', views.delete_noticeboard, name="delete_notice_board"),

    path('admin/class_room/', views.class_room_list, name="class_room"),
    path('admin/create_class_room/', views.add_class_room, name="create_class_room"),
    path('admin/change_class_room/', views.change_class_room, name="change_class_room"),
    path('admin/view_class_room/', views.view_class_room, name="view_class_room"),
    path('admin/delete_class_room/', views.delete_class_room, name="delete_class_room"),

    path('admin/class_room_period/', views.class_room_period_list, name="class_room_period"),
    path('admin/create_class_room_period/', views.add_class_room_period, name="create_class_room_period"),
    path('admin/change_class_room_period/', views.change_class_room_period, name="change_class_room_period"),
    path('admin/view_class_room_period/', views.view_class_room_period, name="view_class_room_period"),
    path('admin/delete_class_room_period/', views.delete_class_room_period, name="delete_class_room_period"),

    path('admin/auditorium/', views.auditorium_list, name="auditorium"),
    path('admin/create_auditorium/', views.add_auditorium, name="create_auditorium"),
    path('admin/change_auditorium/', views.change_auditorium, name="change_auditorium"),
    path('admin/view_auditorium/', views.view_auditorium, name="view_auditorium"),
    path('admin/delete_auditorium/', views.delete_auditorium, name="delete_auditorium"),

    path('admin/lab/', views.lab_list, name="lab"),
    path('admin/create_lab/', views.add_lab, name="create_lab"),
    path('admin/change_lab/', views.change_lab, name="change_lab"),
    path('admin/view_lab/', views.view_lab, name="view_lab"),
    path('admin/delete_lab/', views.delete_lab, name="delete_lab"),

    path('admin/inventory/', views.inventory_list, name="inventory"),
    path('admin/create_inventory/', views.add_inventory, name="create_inventory"),
    path('admin/change_inventory/', views.change_inventory, name="change_inventory"),
    path('admin/view_inventory/', views.view_inventory, name="view_inventory"),
    path('admin/delete_inventory/', views.delete_inventory, name="delete_inventory"),

    path('admin/lab_inventory/', views.lab_inventory_list, name="lab_inventory"),
    path('admin/create_lab_inventory/', views.add_lab_inventory, name="create_lab_inventory"),
    path('admin/change_lab_inventory/', views.change_lab_inventory, name="change_lab_inventory"),
    path('admin/view_lab_inventory/', views.view_lab_inventory, name="view_lab_inventory"),
    path('admin/delete_lab_inventory/', views.delete_lab_inventory, name="delete_lab_inventory"),

    path('admin/class_inventory/', views.class_inventory_list, name="class_inventory"),
    path('admin/create_class_inventory/', views.add_class_inventory, name="create_class_inventory"),
    path('admin/change_class_inventory/', views.change_class_inventory, name="change_class_inventory"),
    path('admin/view_class_inventory/', views.view_class_inventory, name="view_class_inventory"),
    path('admin/delete_class_inventory/', views.delete_class_inventory, name="delete_class_inventory"),





]
