from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

from django.contrib.auth import get_user_model
User = get_user_model()


class Organization(models.Model):
    objects = None
    id = models.AutoField(primary_key=True, unique=True)
    org_name = models.CharField(max_length=255)
    org_code = models.CharField(max_length=255, unique=True)
    org_representative = models.CharField(max_length=255)
    org_type = models.CharField(max_length=255, help_text="Primary, Secondary, Tertiary(university, college, technical "
                                                          "college or university)")
    org_level = models.CharField(max_length=255, help_text="Elementary School, Secondary School")
    org_affiliation = models.CharField(max_length=255, null=True, help_text="ABCD University")
    org_email = models.EmailField(max_length=255, default="abc@email.com")
    org_mobile_no = models.CharField(max_length=12, default=0000000000)
    org_phone_no = models.CharField(max_length=12, default=0000000000)
    org_district = models.CharField(max_length=255)
    org_state = models.CharField(max_length=255)
    org_postal_code = models.CharField(max_length=6, default=000000)
    org_address = models.CharField(max_length=255)
    status = models.BooleanField(default=True)
    created_by = models.IntegerField(default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # class Meta:
    #     abstract = True

    def __str__(self):
        return self.org_name

    def get_org_code(self):
        return self.org_code


class Course(models.Model):
    id = models.AutoField(primary_key=True, unique=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    course_name = models.CharField(max_length=255)
    course_duration = models.IntegerField(default=0,
                                          validators=[
                                              MinValueValidator(1)
                                          ], help_text="course duration in month")
    course_code = models.CharField(max_length=255, unique=True)
    course_type = models.CharField(max_length=255)
    course_available_seats = models.IntegerField(default=0,
                                                 validators=[
                                                     MinValueValidator(1)
                                                 ], help_text="Minimum seats should be 1")
    course_fees = models.IntegerField(default=0,
                                      validators=[
                                          MinValueValidator(1)
                                      ], help_text="Course fees should be mention at least 1")
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.course_name


class SemesterAndYear(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    semester = models.CharField(max_length=255, help_text="If course not falls in semester please mention year. "
                                                          "eg. sem1/year2")
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Subject(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    course_id = models.ForeignKey(Course, on_delete=models.PROTECT)
    subject_name = models.CharField(max_length=255)
    semester = models.ForeignKey(SemesterAndYear, on_delete=models.PROTECT)
    subject_code = models.CharField(max_length=255)
    subject_min_marks = models.IntegerField()
    subject_max_marks = models.IntegerField()
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.subject_name


class Canteen(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    product = models.CharField(max_length=255)
    price = models.CharField(max_length=255)
    level = models.CharField(max_length=255, help_text="Type of food like, veg, non-veg or beverage")
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.product


class Stationery(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    product = models.CharField(max_length=255)
    price = models.IntegerField()
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.product

"""
class AnotherCampusFacilities(models.Model):
    pass
"""


class Session(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    session_year = models.CharField(max_length=255)
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.session_year


class Department(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    department_name = models.CharField(max_length=255)
    incharge_name = models.CharField(max_length=255)
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.department_name

    @property
    def get_department(self):
        department_details = "This class contains various departments of School like English, Tamil,Art, etc."
        return department_details


class NoticeBoard(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    notice = models.CharField(max_length=255)
    level = models.CharField(max_length=255, help_text="Type of notice or priority")
    description = models.TextField()
    
    status = models.IntegerField(default=1)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, default="Guest")
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.notice

    @property
    def display(self):
        notice = "This method is to display all the news or any event details or any new information from the notice " \
                 "board."
        return notice

    @property
    def add_content(self):
        add_data = " This is to add any new content to the notice board.."
        return add_data


class ClassRoom(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    class_name = models.CharField(max_length=255)
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class ClassRoomPeriod(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    class_id = models.ForeignKey(ClassRoom, on_delete=models.PROTECT)
    total_time = models.CharField(max_length=255)
    time_start = models.CharField(max_length=255)
    time_end = models.CharField(max_length=255)
    subject_id = models.ForeignKey(Subject, on_delete=models.PROTECT)
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Auditorium(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    total_seats = models.IntegerField()
    seats_occupied = models.IntegerField()
    event_name = models.CharField(max_length=255)
    event_date = models.DateField()
    event_time = models.TimeField()
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.event_name

    @property
    def book_auditorium(self):
        detail = "This method is to book the auditorium by any department inside the school to conduct any event " \
                 "or guest lectures."
        return detail

    @property
    def event_details(self):
        detail = "This method shows the details of any event on a particular date."
        return detail

    @property
    def display_seat(self):
        detail = "This method displays the available seats in the auditorium for any event"
        return detail

"""
class Playground(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    area = models.CharField(max_length=255)
    class_room_id = models.ForeignKey(ClassRoom, on_delete=models.PROTECT)
    
    status = models.IntegerField(default=1)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, default="Guest")
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.area

    @property
    def is_occupied(self):
        detail = "This method tells whether the playground is occupied or not."
        return detail

"""


class Lab(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    lab_name = models.CharField(max_length=255)
    lab_level = models.CharField(max_length=255, help_text="Extra field to add more information")
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Inventory(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    inventory_name = models.CharField(max_length=255)
    no_of_inventory = models.IntegerField(default=0, blank=False)
    inventory_level = models.CharField(max_length=255, help_text="Extra field to add more information")
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.inventory_name

    @property
    def inventory_details(self):
        inventory_details = "This contains the details of equipment in the lab and also the equipment of class"
        return inventory_details

    @property
    def purchase_inventory(self):
        purchase_inventory = "This method is to purchase the equipment and contains the details of newly " \
                             "purchased equipment."
        return purchase_inventory

    @property
    def repair(self):
        repair = "This method is to repair any equipment."
        return repair


class LabInventory(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    lab_id = models.ForeignKey(Lab, on_delete=models.PROTECT)
    inventory_id = models.ForeignKey(Inventory, on_delete=models.PROTECT)
    count_of_lab_inventory = models.IntegerField()
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.count_of_lab_inventory


class ClassInventory(models.Model):
    id = models.AutoField(primary_key=True)
    # organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    inventory_id = models.ForeignKey(Inventory, on_delete=models.PROTECT)
    class_room_id = models.ForeignKey(ClassRoom, on_delete=models.PROTECT)
    count_of_class_inventory = models.IntegerField()
    
    status = models.IntegerField(default=1)
    # user = models.ForeignKey(User, on_delete=models.PROTECT, default=0)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


