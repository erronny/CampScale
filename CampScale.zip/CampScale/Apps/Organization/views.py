from django.shortcuts import render
from django.shortcuts import (get_object_or_404, render, HttpResponseRedirect)
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from .models import *
from datetime import datetime
from .forms import *
from django.contrib.auth import get_user_model

User = get_user_model()


################################################################

# Organization
@login_required
def organization_list(request):
    context = {}
    context["dataset"] = Organization.objects.filter(is_deleted=False)
    context["trash"] = Organization.objects.filter(is_deleted=True)
    return render(request, 'admin/Organization/Organization/list.html', context)


@login_required
def add_organization(request):
    context = {}
    if request.method == 'POST':
        form = OrganizationCreationFrom(request.POST or None)
        if form.is_valid():
            org_name = form.cleaned_data['org_name']
            org_code = form.cleaned_data['org_code']
            org_representative = form.cleaned_data['org_representative']
            org_type = form.cleaned_data['org_type']
            org_level = form.cleaned_data['org_level']
            org_affiliation = form.cleaned_data['org_affiliation']
            org_email = form.cleaned_data['org_email']
            org_mobile_no = form.cleaned_data['org_mobile_no']
            org_phone_no = form.cleaned_data['org_phone_no']
            org_district = form.cleaned_data['org_district']
            org_state = form.cleaned_data['org_state']
            org_postal_code = form.cleaned_data['org_postal_code']
            org_address = form.cleaned_data['org_address']
            # status = form.cleaned_data['status']
            status = True
            created_by = request.user.id
            is_deleted = False

            organization = Organization(org_name=org_name,
                                        org_code=org_code,
                                        org_representative=org_representative,
                                        org_type=org_type,
                                        org_level=org_level,
                                        org_affiliation=org_affiliation,
                                        org_email=org_email,
                                        org_mobile_no=org_mobile_no,
                                        org_phone_no=org_phone_no,
                                        org_district=org_district,
                                        org_state=org_state,
                                        org_postal_code=org_postal_code,
                                        org_address=org_address,
                                        status=status,
                                        created_by=created_by,
                                        is_deleted=is_deleted)
            # organization.created_by = User.id
            organization.save()
            return HttpResponseRedirect("/"'admin'"/"'organization')
        else:
            print(form.errors)

    else:
        form = OrganizationCreationFrom()
    return render(request, 'admin/Organization/Organization/add.html', {'form': form})


@login_required
def change_organization(request, id):
    context = {}
    # fetch the object related to passed id
    data_obj = Organization.objects.get(id=id)
    form = OrganizationUpdationFrom(instance=data_obj)
    # queryset = Organization.objects.filter(filter=filter)
    # context = {'form': form}
    if request.method == 'POST':
        form = OrganizationUpdationFrom(data=request.POST, instance=data_obj)
        if form.is_valid():
            data = form.cleaned_data
            org_name = data['org_name']
            org_code = data['org_code']
            org_representative = data['org_representative']
            org_type = data['org_type']
            org_level = data['org_level']
            org_affiliation = data['org_affiliation']
            org_email = data['org_email']
            org_mobile_no = data['org_mobile_no']
            org_phone_no = data['org_phone_no']
            org_district = data['org_district']
            org_state = data['org_state']
            org_postal_code = data['org_postal_code']
            org_address = data['org_address']
            status = form.cleaned_data['status']
            # status = 1
            created_by = request.user.id
            is_deleted = False
            created_at = data_obj.created_at

            organization = Organization(id=id,
                                        org_name=org_name,
                                        org_code=org_code,
                                        org_representative=org_representative,
                                        org_type=org_type,
                                        org_level=org_level,
                                        org_affiliation=org_affiliation,
                                        org_email=org_email,
                                        org_mobile_no=org_mobile_no,
                                        org_phone_no=org_phone_no,
                                        org_district=org_district,
                                        org_state=org_state,
                                        org_postal_code=org_postal_code,
                                        org_address=org_address,
                                        status=status,
                                        created_by=created_by,
                                        created_at=created_at,
                                        is_deleted=is_deleted)

            organization.save()
            # Create Subscriber Record
            # address_one = form.cleaned_data['address_one']
            # address_two = form.cleaned_data['address_two']
            # city = form.cleaned_data['city']
            # state = form.cleaned_data['state']
            # sub = Subscriber(address_one=address_one, address_two=address_two,
            #                  city=city, state=state, user_rec=user)
            # sub.save()
            return HttpResponseRedirect("/"'admin'"/"'organization')
        else:
            print(form.errors)
            # form = OrganizationCreationFrom(instance=data)
    return render(request, 'admin/Organization/Organization/change.html', {'form': form})


@login_required
def enable_organization(request, id):
    # fetch the object related to passed id
    data_obj = Organization.objects.get(id=id)
    data_obj.status = True
    data_obj.save(update_fields=["status"])
    return HttpResponseRedirect("/"'admin'"/"'organization')


@login_required
def disable_organization(request, id):
    # fetch the object related to passed id
    data_obj = Organization.objects.get(id=id)
    data_obj.status = False
    data_obj.save(update_fields=["status"])
    return HttpResponseRedirect("/"'admin'"/"'organization')


@login_required
def trash_organization(request, id):
    # fetch the object related to passed id
    data_obj = Organization.objects.get(id=id)
    data_obj.is_deleted = True
    data_obj.save(update_fields=["is_deleted"])
    return HttpResponseRedirect("/"'admin'"/"'organization')


@login_required
def restore_organization(request, id):
    # fetch the object related to passed id
    data_obj = Organization.objects.get(id=id)
    data_obj.is_deleted = False
    data_obj.save(update_fields=["is_deleted"])
    return HttpResponseRedirect("/"'admin'"/"'organization')


@login_required
def view_organization(request, id):
    context = {}
    context["data"] = Organization.objects.get(id=id)
    return render(request, 'admin/Organization/Organization/view.html', context)


@login_required
def delete_organization(request, id):
    # fetch the object related to passed id
    data_obj = Organization.objects.get(id=id)
    # data_obj.is_deleted = False
    # data_obj.save(update_fields=["is_deleted"])
    data_obj.delete()
    return HttpResponseRedirect("/"'admin'"/"'organization')


########################################################
# Course
@login_required
def course_list(request):
    return render(request, 'admin/Organization/Course/list.html')


@login_required
def add_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST or None)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/"'admin'"/"'organization')
        else:
            print(form.errors)
    else:
        form = CourseForm()

    return render(request, 'admin/Organization/Course/add.html', {'form': form})


@login_required
def change_course(request):
    return render(request, 'admin/Organization/Course/change.html')


@login_required
def view_course(request):
    return render(request, 'admin/Organization/Course/view.html')


@login_required
def delete_course(request):
    return render(request, 'admin/Organization/view.html')


########################################################
# SemesterAndYear
@login_required
def semester_year_list(request):
    return render(request, 'admin/Organization/Semester/list.html')


@login_required
def add_semester_year(request):
    return render(request, 'admin/Organization/Semester/add.html')


@login_required
def change_semester_year(request):
    return render(request, 'admin/Organization/Semester/change.html')


@login_required
def view_semester_year(request):
    return render(request, 'admin/Organization/Semester/view.html')


@login_required
def delete_semester_year(request):
    return render(request, 'admin/Organization/view.html')


########################################################
# subject
@login_required
def subject_list(request):
    return render(request, 'admin/Organization/Course/Subject/list.html')


@login_required
def add_subject(request):
    form = CourseForm()
    return render(request, 'admin/Organization/Course/Subject/add.html')


@login_required
def change_subject(request):
    return render(request, 'admin/Organization/Course/Subject/change.html')


@login_required
def view_subject(request):
    return render(request, 'admin/Organization/Course/Subject/view.html')


@login_required
def delete_subject(request):
    return render(request, 'admin/Organization/view.html')


########################################################
# Canteen
@login_required
def canteen_list(request):
    return render(request, 'admin/Organization/Canteen/list.html')


@login_required
def add_canteen(request):
    return render(request, 'admin/Organization/Canteen/add.html')


@login_required
def change_canteen(request):
    return render(request, 'admin/Organization/Canteen/change.html')


@login_required
def view_canteen(request):
    return render(request, 'admin/Organization/Canteen/view.html')


@login_required
def delete_canteen(request):
    return render(request, 'admin/Organization/view.html')


########################################################
# Stationery
@login_required
def stationery_list(request):
    return render(request, 'admin/Organization/Stationery/list.html')


@login_required
def add_stationery(request):
    return render(request, 'admin/Organization/Stationery/add.html')


@login_required
def change_stationery(request):
    return render(request, 'admin/Organization/Stationery/change.html')


@login_required
def view_stationery(request):
    return render(request, 'admin/Organization/Stationery/view.html')


@login_required
def delete_stationery(request):
    return render(request, 'admin/Organization/view.html')


########################################################

# Session
@login_required
def session_list(request):
    return render(request, 'admin/Organization/Session/list.html')


@login_required
def add_session(request):
    return render(request, 'admin/Organization/Session/add.html')


@login_required
def change_session(request):
    return render(request, 'admin/Organization/Session/change.html')


@login_required
def view_session(request):
    return render(request, 'admin/Organization/Session/view.html')


@login_required
def delete_session(request):
    return render(request, 'admin/Organization/Session/view.html')


########################################################

# Department
@login_required
def department_list(request):
    return render(request, 'admin/Organization/Department/list.html')


@login_required
def add_department(request):
    return render(request, 'admin/Organization/Department/add.html')


@login_required
def change_department(request):
    return render(request, 'admin/Organization/Department/change.html')


@login_required
def view_department(request):
    return render(request, 'admin/Organization/Department/view.html')


@login_required
def delete_department(request):
    return render(request, 'admin/Organization/view.html')


########################################################

# Noticeboard
@login_required
def noticeboard_list(request):
    return render(request, 'admin/Organization/NoticeBoard/list.html')


@login_required
def add_noticeboard(request):
    return render(request, 'admin/Organization/NoticeBoard/add.html')


@login_required
def change_noticeboard(request):
    return render(request, 'admin/Organization/NoticeBoard/change.html')


@login_required
def view_noticeboard(request):
    return render(request, 'admin/Organization/NoticeBoard/view.html')


@login_required
def delete_noticeboard(request):
    return render(request, 'admin/Organization/view.html')


########################################################

# ClassRoom
@login_required
def class_room_list(request):
    return render(request, 'admin/Organization/ClassRoom/list.html')


@login_required
def add_class_room(request):
    return render(request, 'admin/Organization/ClassRoom/add.html')


@login_required
def change_class_room(request):
    return render(request, 'admin/Organization/ClassRoom/change.html')


@login_required
def view_class_room(request):
    return render(request, 'admin/Organization/ClassRoom/view.html')


@login_required
def delete_class_room(request):
    return render(request, 'admin/Organization/view.html')


########################################################
#  ClassRoomPeriod
@login_required
def class_room_period_list(request):
    return render(request, 'admin/Organization/ClassRoom/ClassRoomPeriod/list.html')


@login_required
def add_class_room_period(request):
    return render(request, 'admin/Organization/ClassRoom/ClassRoomPeriod/add.html')


@login_required
def change_class_room_period(request):
    return render(request, 'admin/Organization/ClassRoom/ClassRoomPeriod/change.html')


@login_required
def view_class_room_period(request):
    return render(request, 'admin/Organization/ClassRoom/ClassRoomPeriod/view.html')


@login_required
def delete_class_room_period(request):
    return render(request, 'admin/Organization/view.html')


########################################################

#  Auditorium
@login_required
def auditorium_list(request):
    return render(request, 'admin/Organization/ClassRoom/ClassRoomPeriod/list.html')


@login_required
def add_auditorium(request):
    return render(request, 'admin/Organization/ClassRoom/ClassRoomPeriod/add.html')


@login_required
def change_auditorium(request):
    return render(request, 'admin/Organization/ClassRoom/ClassRoomPeriod/change.html')


@login_required
def view_auditorium(request):
    return render(request, 'admin/Organization/ClassRoom/ClassRoomPeriod/view.html')


@login_required
def delete_auditorium(request):
    return render(request, 'admin/Organization/view.html')


########################################################
#  Lab
@login_required
def lab_list(request):
    return render(request, 'admin/Organization/Lab/list.html')


@login_required
def add_lab(request):
    return render(request, 'admin/Organization/Lab/add.html')


@login_required
def change_lab(request):
    return render(request, 'admin/Organization/Lab/change.html')


@login_required
def view_lab(request):
    return render(request, 'admin/Organization/Lab/view.html')


@login_required
def delete_lab(request):
    return render(request, 'admin/Organization/view.html')


########################################################
#  Inventory
@login_required
def inventory_list(request):
    return render(request, 'admin/Organization/Inventory/list.html')


@login_required
def add_inventory(request):
    return render(request, 'admin/Organization/Inventory/add.html')


@login_required
def change_inventory(request):
    return render(request, 'admin/Organization/Inventory/change.html')


@login_required
def view_inventory(request):
    return render(request, 'admin/Organization/Inventory/view.html')


@login_required
def delete_inventory(request):
    return render(request, 'admin/Organization/view.html')


########################################################

#  ClassInventory
@login_required
def class_inventory_list(request):
    return render(request, 'admin/Organization/Inventory/ClassRoomInventory/list.html')


@login_required
def add_class_inventory(request):
    return render(request, 'admin/Organization/Inventory/ClassRoomInventory/add.html')


@login_required
def change_class_inventory(request):
    return render(request, 'admin/Organization/Inventory/ClassRoomInventory/change.html')


@login_required
def view_class_inventory(request):
    return render(request, 'admin/Organization/Inventory/ClassRoomInventory/view.html')


@login_required
def delete_class_inventory(request):
    return render(request, 'admin/Organization/view.html')


########################################################
#  LabInventory
@login_required
def lab_inventory_list(request):
    return render(request, 'admin/Organization/Inventory/LabInventory/list.html')


@login_required
def add_lab_inventory(request):
    return render(request, 'admin/Organization/Inventory/LabInventory/add.html')


@login_required
def change_lab_inventory(request):
    return render(request, 'admin/Organization/Inventory/LabInventory/change.html')


@login_required
def view_lab_inventory(request):
    return render(request, 'admin/Organization/Inventory/LabInventory/view.html')


@login_required
def delete_lab_inventory(request):
    return render(request, 'admin/Organization/view.html')

########################################################
