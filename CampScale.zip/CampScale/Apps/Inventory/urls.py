from django.urls import path
from . import views

app_name = 'Inventory'
urlpatterns = [

    path('admin/inventory/', views.index, name="inventory"),
    path('admin/create_inventory/', views.add, name="create_inventory"),
    path('admin/change_inventory/', views.change, name="change_inventory"),
    path('admin/view_inventory/', views.index, name="view_inventory"),

]