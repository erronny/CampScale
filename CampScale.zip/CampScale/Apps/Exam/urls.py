from django.urls import path
from . import views

app_name = 'Exam'
urlpatterns = [
    # path('', views.index, name="home"),
    path('admin/exam/', views.index, name="exams"),
    path('admin/create_exam/', views.add, name="create_exam"),
    path('admin/change_exam/<id>', views.change, name="change_exam"),
    path('admin/exam/<id>', views.view, name="exams"),

]