from django.db import models

class Question(models.Model):
    # fields of the model

    questions = models.CharField(max_length=200)
    option1 = models.TextField()
    option2 = models.TextField()
    option3 = models.TextField()
    option4 = models.TextField()
    answer = models.TextField()


    # renames the instance of the model
    #with their title name
    def __str__(self):
        return self.questions
















