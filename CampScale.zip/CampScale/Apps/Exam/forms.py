from django import forms
from .models import Question


# creating a from
class QuestionForm(forms.ModelForm):
    questions = forms.CharField(widget=forms.TextInput(attrs={'type': 'text',
                                                              'id': 'questions', 'name': 'questions',
                                                              'value': "", 'class': 'form-control'}))

    option1 = forms.CharField(widget=forms.TextInput(attrs={'type': 'text',
                                                              'id': 'option1', 'name': 'option1',
                                                              'value': "", 'class': 'form-control'}))
    option2 = forms.CharField(widget=forms.TextInput(attrs={'type': 'text',
                                                              'id': 'option2', 'name': 'option2',
                                                              'value': "", 'class': 'form-control'}))
    option3 = forms.CharField(widget=forms.TextInput(attrs={'type': 'text',
                                                              'id': 'option3', 'name': 'option3',
                                                              'value': "", 'class': 'form-control'}))
    option4 = forms.CharField(widget=forms.TextInput(attrs={'type': 'textarea',
                                                              'id': 'option4', 'name': 'option4',
                                                              'value': "", 'class': 'form-control'}))
    answer = forms.CharField(widget=forms.TextInput(attrs={'type': 'text',
                                                              'id': 'answer', 'name': 'answer',
                                                              'value': "", 'class': 'form-control'}))

    # create meta class
    class Meta:
        # specify model to be used
        model = Question
        exclude = ()
        # specify fields to be used
        # fields = [
        #     "questions",
        #     "option1",
        #     "option2",
        #     "option3",
        #     "option4",
        #     "answer",
        #
        # ]
