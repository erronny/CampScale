from django.shortcuts import (get_object_or_404, render, HttpResponseRedirect)
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import authenticate, login, logout

# relative import of forms
from .models import Question
from .forms import QuestionForm


@login_required
@permission_required("is_staff")

def index(request):
    # dictionary for initial data with field name as keys
    context ={}

    context["dataset"] = Question.objects.all()
    return render(request, "admin/Exam/list.html", context)


@login_required
def add(request):
    # dictionary for initial data with
    # field names as keys
    context = {}

    # add the dictionary during initialization
    form = QuestionForm(request.POST or None)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect("/"'admin'"/"'exam')
    context['form'] = form
    return render(request, "admin/Exam/add.html", context)


@login_required
def change(request, id):
    context = {}
    # fetch the object related to passed id
    obj = get_object_or_404(Question, id=id)

    # pass the object as instance in form
    form = QuestionForm(request.POST or None, instance=obj)

    # save the data from the form and redirect to view
    if form.is_valid():
        form.save()
        return HttpResponseRedirect("/"'admin'"/"'exam')

    # add form dictionary to context
    context["form"] = form
    return render(request, "admin/Exam/change.html", context)


@login_required
def view(request, id):
    context = {}

    context["data"] = Question.objects.get(id=id)
    return render(request, "admin/Exam/view.html", context)