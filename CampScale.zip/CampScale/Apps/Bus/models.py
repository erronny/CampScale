from django.db import models
from Apps.Organization.models import Organization

"""
class Driver(models.Model):
    id = models.AutoField(primary_key=True)
    organization_id = models.ForeignKey(Organization, on_delete=models.CASCADE)
    driver_name = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.driver_name

    def get_driver(self):
        driver = "details of driver"
        return driver


class Bus(models.Model):
    id = models.AutoField(primary_key=True)
    organization_id = models.ForeignKey(Organization, on_delete=models.CASCADE)
    driver_id = models.ForeignKey(Driver, on_delete=models.CASCADE)
    area_list = models.CharField(max_length=255)
    bus_number = models.CharField(max_length=255)
    capacity = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.bus_number

    def get_bus_details(self):
        bus_detail =  "This method contains the details of the bus."
        return bus_detail

    def show_seats(self):
        get_seat = "This shows the seat details in a particular bus."
        return get_seat
"""