from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout


@login_required
def index(request):
    return render(request, 'admin/Salary/list.html')


@login_required
def add(request):
    return render(request, 'admin/Salary/add.html')


@login_required
def change(request):
    return render(request, 'admin/Salary/change.html')


@login_required
def view(request):
    return render(request, 'admin/Salary/view.html')
