from django.urls import path
from . import views

app_name = 'Salary'
urlpatterns = [
    # path('', views.index, name="home"),
    path('admin/salary/', views.index, name="salary"),
    path('admin/create_salary/', views.add, name="create_salary"),
    path('admin/change_salary/', views.change, name="change_salary"),
    # path('admin/exam/', views.index, name="exams"),

]