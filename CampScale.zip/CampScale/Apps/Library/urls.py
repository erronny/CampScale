from django.urls import path
from . import views

app_name = 'Library'
urlpatterns = [

    path('admin/library/', views.index, name="library"),
    path('admin/create_library/', views.add, name="create_library"),
    path('admin/change_library/', views.change, name="change_library"),
    path('admin/view_library/', views.index, name="view_library"),

]