from django.db import models
"""
from Apps.Organizations.models import Organization


class Library(models.Model):
    id = models.AutoField(primary_key=True)
    organization_id = models.ForeignKey(Organization, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    address = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Librarian(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Author(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Language(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    name = models.CharField(max_length=22, help_text="Enter the book's natural language (e.g. English, French, Japanese etc.)")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.name


class Catalog(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    name = models.CharField(max_length=255, help_text="Enter a book genre (e.g. Science Fiction, French Poetry etc.)")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str_(self):
        return self.name


class Book(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    isbn = models.CharField(max_length=255)
    total_copies = models.IntegerField()
    available_copies = models.IntegerField()
    subject = models.CharField(max_length=255)
    summary = models.TextField(max_length=1000)
    catalog = models.ManyToManyField(Catalog, help_text="Select a genre for this book")
    language = models.ForeignKey(Language, on_delete=models.SET_NULL, null=True)
    publication = models.CharField(max_length=255)
    number_of_pages = models.IntegerField()
    pic = models.ImageField(blank=True, null=True, upload_to='book_image')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title


class BookItem(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    barcode = models.CharField(max_length=255)
    isReferenceOnly = models.BooleanField()
    borrowed = models.DateField()
    dueDate = models.DateField()
    price = models.CharField(max_length=255)
    format = models.CharField(max_length=255)
    status = models.CharField(max_length=255)
    dateOfPurchase = models.DateField(max_length=255)
    publicationDate = models.DateField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.barcode


class LibraryCard(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    cardNumber = models.CharField(max_length=255)
    barcode = models.CharField(max_length=255)
    issueAt = models.DateField()
    active = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.cardNumber


class BookReservation(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    creationDate = models.DateTimeField()
    status = models.CharField(max_length=255, help_text="ReservationStatus")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.creationDate


class BookLending(models.Model):
    id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    creationDate = models.DateField()
    dueDate = models.DateField()
    returnDate = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.creationDate


class Fine(models.Model):
    amount = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Rack(models.Model):
    number = models.IntegerField()
    locationIdentifier = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
"""
