from django.urls import path
from . import views

app_name = 'Result'
urlpatterns = [

    path('admin/result/', views.index, name="organization"),
    path('admin/create_result/', views.add, name="create_result"),
    path('admin/change_result/', views.change, name="change_result"),
    path('admin/view_result/', views.index, name="view_result"),

]