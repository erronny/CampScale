from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout


@login_required
def index(request):
    return render(request, 'admin/Result/list.html')


@login_required
def add(request):
    return render(request, 'admin/Result/add.html')


@login_required
def change(request):
    return render(request, 'admin/Result/change.html')


@login_required
def view(request):
    return render(request, 'admin/Result/view.html')
