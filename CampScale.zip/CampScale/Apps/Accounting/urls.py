from django.urls import path
from . import views

app_name = 'Accounting'
urlpatterns = [
    # path('', views.index, name="home"),
    path('admin/account_section/', views.index, name="account_section"),
    path('admin/create_fee/', views.add, name="create_fee"),
    path('admin/change_fee/', views.change, name="change_fee"),
    path('admin/view_fee/', views.index, name="view_fee"),

]